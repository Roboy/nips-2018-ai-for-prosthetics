#!/usr/bin/env bash
conda create -n opensim-rl -c kidzik opensim git python=3.5.2 anaconda -y
